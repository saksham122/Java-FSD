package practiceproject;

public class Exthread extends Thread{
	public void run()
 	{
  		System.out.println("running");
}
 	public static void main( String args[] )
 	{
 		Exthread ex = new  Exthread();
  		ex.start();
  		
  		ex.run();
 	}
}

