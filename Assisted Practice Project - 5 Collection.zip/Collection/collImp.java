package collection;
import java.util.*;
public class collImp {

	public static void main(String[] args) {
		
        System.out.println("ArrayList");
        ArrayList<Integer> A = new ArrayList<>();
        A.add(1);
        A.add(2);
        A.add(3);
        A.add(4);
        A.add(5);
        A.add(6);
        System.out.println(A);
        
        System.out.println("LinkedList");
        LinkedList<String> l =new LinkedList<>();
        l.add("hii");
        l.add("discord");
        l.add("world");
        l.add("soon");
        Iterator<String> it=l.iterator();  
	      while(it.hasNext()){  
	       System.out.println(it.next());  
	      }
      
        
        System.out.println("HashSET");
        
	       HashSet<Integer> HS=new HashSet<Integer>();  
	       HS.add(1);  
	       HS.add(10);  
	       HS.add(20);
	       HS.add(11);
	       System.out.println(HS);
	       
	      
	       System.out.println("LinkedHashSet Implementation");
	       LinkedHashSet<Integer> lhs=new LinkedHashSet<Integer>();  
	       lhs.add(10);  
	       lhs.add(37);  
	       lhs.add(82);
	      lhs.add(764);	       
	       System.out.println(lhs);
	       System.out.println("\n");
		      System.out.println("Vector implemetation");
		      Vector<Integer> v = new Vector();
		      v.addElement(108); 
		      v.addElement(290); 
		      v.addElement(780); 
		      v.addElement(510); 
		      System.out.println(v);


        

	}

}
