package InnerClass;
abstract class AnonymousInnerClass {
	   public abstract void display();
	}
public class InnerClass {
	private String s="Local Innner Classes";
	class MemberClass
	{
		private int id=10;
		void msg() 
		{
			System.out.println("Member inner class");
		}
		
	}
	void display(){  
		 class LocalInner{  
			 void msg(){
				 System.out.println(s);
			 }  
	  }  
	  
	  LocalInner li=new LocalInner();  
	  li.msg();  
	 }  
	



	public static void main(String[] args) {
		InnerClass ic = new InnerClass();
		InnerClass.MemberClass mc = ic.new  MemberClass();
		mc.msg();
		System.out.println("member calss variable "+mc.id);
          obj.display();
          AnonymousInnerClass ac = new AnonymousInnerClass() {

 	         public void display() {
 	            System.out.println("Anonymous Inner Class");
 	         }
 	      };
 	      ac.display();

         
	}

}
