import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo';
  product:Array<any>=[{name:"Rice",price:200},{name:"salt",price:150}];

  public clickCount:number=0;
CountChanged(count:number):void{
  this.clickCount=count;
}

}

