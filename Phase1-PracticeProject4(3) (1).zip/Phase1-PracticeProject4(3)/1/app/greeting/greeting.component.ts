import { Component, EventEmitter, Input, OnInit,Output } from '@angular/core';

@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.css']
})
export class GreetingComponent implements OnInit {
  username:String="";
  pass:String="";
  msg="";
  status:String='error';
  cssStringVar:String='';
  constructor() { }
  //property binding from parent to child
  @Input() productList:Array<any>=[];
  
  ngOnInit(): void {
  }
  validation()
  {
    if(this.username=="abc" && this.pass=="123")
    {
      this.status='';
      this.msg="welcome"+this.username;
    }
    else
    {
      this.msg="invalid";
      this.status='error';
      this.cssStringVar='red size20';

    }
    this.username="";
    this.pass="";

  }
  //Count change on @Output
  public clickCount:number=0;
  @Output() onChanged=new EventEmitter<number>();

  countChange(count : number){
  count++;
  this.clickCount=count;
  this.onChanged.emit(this.clickCount);
   }

}
