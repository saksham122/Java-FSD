import { TempchangePipe } from './tempchange.pipe';

describe('TempchangePipe', () => {
  it('create an instance', () => {
    const pipe = new TempchangePipe();
    expect(pipe).toBeTruthy();
  });
});
