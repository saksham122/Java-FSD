package ConstructorExample;

public class CreateConstructor {
	String n;
	CreateConstructor()
	{
		System.out.println("default constructor");
	}
	CreateConstructor(String n)
	{
		this.n = n ;
	
	}
	 void display()
	 {
		 System.out.println(n);
		 }  
	public static void main(String args[]) 
	{
        CreateConstructor cc = new CreateConstructor();
        System.out.println("parameterised constructor");
        CreateConstructor cc1 = new CreateConstructor("test");
        cc1.display();
        
		
	}
}