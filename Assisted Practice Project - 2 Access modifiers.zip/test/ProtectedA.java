package test;

public class ProtectedA {
	protected void text()
	{
		System.out.println("Protected is using");
		}  
}



