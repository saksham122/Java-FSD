package test;
public class Publicmain {
	public void display() 
    { 
        System.out.println(" Public Access Specifiers"); 
    } 

}

