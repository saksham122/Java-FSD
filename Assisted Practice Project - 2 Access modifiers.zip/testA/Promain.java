package testA;

import test.*;

public class Promain extends ProtectedA{

	public static void main(String[] args) {
	 Promain pro  =  new Promain();
	 pro.msg();

	}

}

