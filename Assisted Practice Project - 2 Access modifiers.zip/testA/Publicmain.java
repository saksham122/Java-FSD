package testA;

import test.*;
public class Publicmain {
	public static void main(String args[]) 
	{
		Publicmain pu  = new Publicmain();
		pu.display();
	}

}
