package testA;

class A
{
    void text() 
    {
    	System.out.println("deafult");
    }
}
public class DefaultMain {
	public static void main(String args[]) 
	{
		A a  =  new A();
		a.msg();
	}

}
