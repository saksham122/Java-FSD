package testA;
class M
{ 
	private  int p ;
	public void setAge(int p) {
	    this.p = p;
	  }
	public int getData() {
	    return this.p;
	  }

  
} 


public class PrivateModifier {

	public static void main(String[] args) {
		
		M m  =  new M();
	   
	    m.setAge(50);
	    System.out.println(m.getData());

	}

}
