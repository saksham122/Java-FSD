package practiceProject16;


class cusException extends Exception {
	String str1;

	cusException(String str2) {
		str1 = str2;
	}

	public String toString() {
		return ("cusException Occurred: " + str1);
	}
}

class ExceptionHandaling {
	public static void main(String args[]) {
		try {
			System.out.println("Try block");
			
			throw new cusException("Error Message");
		} catch (cusException e) {
			System.out.println("Catch Block");
			System.out.println(e);
		}
	}
}