package practiceProject15;
class MyException extends Exception{

	public String toString() {
		return "You are not eligible for vote";
	}
	
}
public class custException {
	static void  validate(int balance)throws MyException{
		if(balance <18){
			throw new MyException();
		}
		else
			System.out.println("welcome to vote");
	}
	public static void main(String[] args) {
		
		try{
			validate(15);
		}
		catch(MyException e){
			System.out.println(e);
		}

	}

}