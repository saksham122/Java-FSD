package practiceProject15;

public class throw1
{
    public static void main(String[] args)
    {

        int a=45,b=0,s;

        try
        {
            if(b==0)        
                throw(new ArithmeticException("Cant perform this operation"));
            else
            {
                s = a / b;
                System.out.print("\n\tThe result is : " + s);
            }
        }
        catch(ArithmeticException e)
        {
            System.out.print("Error : " + e.getMessage());
        }

        
    }
}
