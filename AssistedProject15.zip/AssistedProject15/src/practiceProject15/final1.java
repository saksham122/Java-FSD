package practiceProject15;

public class final1
{
    public static void main(String[] args)
    {
        int a=45,b=0,s=0;
        try
        {
            s = a / b;
        }
        catch(ArithmeticException e)
        {
            System.out.print("Error : " + e.getMessage());
        }
        finally
        {
            System.out.print("The result: " + s);
        }
    }
}