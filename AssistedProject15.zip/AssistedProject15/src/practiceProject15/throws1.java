package practiceProject15;

public class throws1
{
    void Division() throws ArithmeticException
    {
        int a=45,b=0,s;
        s = a / b;
        System.out.print("\n\tThe result is : " + s);
    }
     public static void main(String[] args)
    {
    	 throws1 T = new throws1();
         try
        {
            T.Division();
        }
        catch(ArithmeticException e)
        {
            System.out.print("\n\tError : " + e.getMessage());
        }
        
    }
}