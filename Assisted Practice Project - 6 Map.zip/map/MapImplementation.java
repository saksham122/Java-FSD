package map;
import java.util.*;
public class MapImplementation {

	public static void main(String[] args) {
		HashMap<String,String> hm=new HashMap<String,String>();      
	      hm.put("T","Taj");    
	      hm.put("S","Shayam");    
	      hm.put("Sa","Sanju");  
	      hm.put("So","sonu");
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	     
	       
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(77,"kanhiya");  
	      ht.put(45,"rk");  
	      ht.put(89,"pk");  
	      ht.put(76,"Jk");  


	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	     
	      
	      TreeMap<Integer,Integer> tm=new TreeMap<Integer,Integer>();    
	      tm.put(7,95);    
	      tm.put(9,85); 
	      tm.put(9,183);
	      tm.put(56,486);       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:tm.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      


	}

}
