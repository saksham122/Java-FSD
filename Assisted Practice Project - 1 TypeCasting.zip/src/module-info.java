module TypeCast {
}