package practiceProject13;


class table{

  void printTable(int n, Thread t){
  
	  synchronized(this) {  
		  System.out.println("Thread id="+t.getId());
		  for(int i=1;i<=5;i++){
			  System.out.println(n*i);
			  try{
				  Thread.sleep(400);
			  }
			  catch(Exception e)
			  {
				  System.out.println(e);
			  }
		  }
	 }
	 
	 
   System.out.println("Square of a number="+ n*n+ " id="+ t.getId());
 }
}
 
class tread1 extends Thread{
	table t;
	tread1(table t){
	this.t=t;
	}

	public void run(){
	t.printTable(5,this);
	}

}

class tread2 extends Thread{
	table t;
	tread2(table t){
	this.t=t;
	}
	public void run(){
	t.printTable(100,this);
	}
}

public class ThreadSyn{
	public static void main(String args[]){
		table obj = new table();
		tread1 t1=new tread1(obj);
		tread2 t2=new tread2(obj);
		t1.start();
		t2.start();
	}
}